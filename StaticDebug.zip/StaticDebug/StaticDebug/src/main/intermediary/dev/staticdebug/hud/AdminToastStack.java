package dev.staticdebug.hud;

import dev.staticdebug.render.AdminHeadTextures;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1109;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;

public final class AdminToastStack {
   private static final int WIDTH = 210;
   private static final int HEIGHT = 40;
   private static final int GAP = 2;
   private static final int MARGIN = 6;
   private static final long DURATION_MS = 5500L;
   private static final long SLIDE_MS = 220L;
   private static final int BG = -267777520;
   private static final int ONLINE = -12723084;
   private static final int OFFLINE = -42422;
   private static final int SUBTLE = -5197636;
   private static final int BAR_BG = -16119284;
   private final List<Entry> entries = new ArrayList();

   public void push(String adminKey, boolean online, boolean playSound) {
      this.entries.add(0, new Entry(adminKey, online, playSound));

      while(this.entries.size() > 6) {
         this.entries.remove(this.entries.size() - 1);
      }

   }

   public void clear() {
      this.entries.clear();
   }

   public void render(class_332 graphics) {
      class_310 mc = class_310.method_1551();
      if (graphics != null && !this.entries.isEmpty() && mc != null && mc.field_1772 != null) {
         long now = System.currentTimeMillis();
         Iterator<Entry> iterator = this.entries.iterator();

         while(iterator.hasNext()) {
            Entry entry = (Entry)iterator.next();
            if (now - entry.start >= 5500L) {
               iterator.remove();
            }
         }

         if (!this.entries.isEmpty()) {
            int y = 6;

            for(Entry entry : this.entries) {
               long elapsed = now - entry.start;
               float life = Math.min(1.0F, (float)elapsed / 5500.0F);
               float slide = easeOut(Math.min(1.0F, (float)elapsed / 220.0F));
               float fadeIn = Math.min(1.0F, (float)elapsed / 140.0F);
               float fadeOut = elapsed > 5100L ? 1.0F - (float)(elapsed - 5100L) / 400.0F : 1.0F;
               float alpha = fadeIn * fadeOut;
               int panelAlpha = clamp((int)(alpha * 255.0F), 0, 255);
               if (panelAlpha <= 4) {
                  y += 42;
               } else {
                  if (!entry.playedSound && entry.playSound && mc.method_1483() != null) {
                     entry.playedSound = true;
                     mc.method_1483().method_4873(entry.online ? class_1109.method_4757(class_3417.field_14561, 0.55F, 1.15F) : class_1109.method_4757(class_3417.field_14641, 0.45F, 0.9F));
                  }

                  int slideX = (int)((1.0F - slide) * 12.0F);
                  int x = 6 + slideX;
                  int accent = entry.online ? -12723084 : -42422;
                  graphics.method_25294(x, y, x + 210, y + 40, withAlpha(-267777520, panelAlpha));
                  graphics.method_25294(x + 1, y + 10, x + 3, y + 40 - 10, withAlpha(accent, panelAlpha));
                  AdminHeadTextures.drawHead(graphics, entry.adminKey, x + 8, y + 12, 16);
                  String var10000 = AdminHeadTextures.displayName(entry.adminKey);
                  String title = (var10000 + (entry.online ? " IS NOW ONLINE" : " IS NOW OFFLINE")).toUpperCase(Locale.ROOT);
                  graphics.method_25303(mc.field_1772, title, x + 30, y + 9, withAlpha(accent, panelAlpha));
                  graphics.method_25303(mc.field_1772, entry.online ? "Joined tab" : "Left tab", x + 30, y + 22, withAlpha(-5197636, Math.min(panelAlpha, 220)));
                  int barLeft = x + 6;
                  int barRight = x + 210 - 6;
                  int fill = Math.max(0, (int)((float)(barRight - barLeft) * (1.0F - life)));
                  graphics.method_25294(barLeft, y + 40 - 3, barRight, y + 40 - 1, withAlpha(-16119284, panelAlpha));
                  if (fill > 0) {
                     graphics.method_25294(barLeft, y + 40 - 3, barLeft + fill, y + 40 - 1, withAlpha(accent, panelAlpha));
                  }

                  y += 42;
               }
            }

         }
      }
   }

   private static int withAlpha(int color, int alpha) {
      int sourceAlpha = color >>> 24 & 255;
      int a = sourceAlpha == 0 ? alpha : Math.min(alpha, sourceAlpha);
      return a << 24 | color & 16777215;
   }

   private static float easeOut(float t) {
      float inverse = 1.0F - t;
      return 1.0F - inverse * inverse * inverse;
   }

   private static int clamp(int value, int min, int max) {
      return Math.max(min, Math.min(max, value));
   }

   private static final class Entry {
      private final String adminKey;
      private final boolean online;
      private final boolean playSound;
      private final long start = System.currentTimeMillis();
      private boolean playedSound;

      private Entry(String adminKey, boolean online, boolean playSound) {
         this.adminKey = adminKey;
         this.online = online;
         this.playSound = playSound;
      }
   }
}
