@echo off
setlocal
set "GRADLE_VERSION=9.2.1"
set "GRADLE_HOME=%USERPROFILE%\.gradle\manual\gradle-%GRADLE_VERSION%"
set "GRADLE_ZIP=%TEMP%\gradle-%GRADLE_VERSION%-bin.zip"

if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Gradle %GRADLE_VERSION% is not cached. Downloading from the official Gradle distribution server...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ZIP%'; New-Item -ItemType Directory -Force -Path '%USERPROFILE%\.gradle\manual' | Out-Null; Expand-Archive -LiteralPath '%GRADLE_ZIP%' -DestinationPath '%USERPROFILE%\.gradle\manual' -Force; Remove-Item -LiteralPath '%GRADLE_ZIP%' -Force"
  if errorlevel 1 (
    echo ERROR: Could not download or extract Gradle. Check your internet connection and PowerShell.
    exit /b 1
  )
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
