package dev.staticdebug.render;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1068;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_640;
import net.minecraft.class_7532;
import net.minecraft.class_8685;

public final class AdminHeadTextures {
   public static final Map<String, String> TEXTURE_FILES;
   private static final Map<String, class_2960> TEXTURES;
   private static final Set<String> MISSING = ConcurrentHashMap.newKeySet();

   private AdminHeadTextures() {
   }

   public static String displayName(String key) {
      if (key == null) {
         return "";
      } else {
         String trimmed = key.trim();
         return trimmed.isEmpty() ? "" : trimmed;
      }
   }

   public static String assetName(String key) {
      if (key == null) {
         return "";
      } else {
         String normalized = key.trim().toLowerCase(Locale.ROOT);
         return (String)TEXTURE_FILES.getOrDefault(normalized, normalized);
      }
   }

   public static void drawHead(class_332 graphics, String key, int x, int y, int size) {
      if (graphics != null && key != null) {
         String username = key.trim();
         if (!username.isEmpty()) {
            class_2960 local = localTexture(username);
            if (local != null) {
               class_7532.method_44445(graphics, local, x, y, size, true, false, -1);
            } else {
               class_8685 skin = resolveFromTab(username);
               if (skin == null) {
                  UUID uuid = UUID.nameUUIDFromBytes(username.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.UTF_8));
                  skin = class_1068.method_4648(uuid);
               }

               class_7532.method_52722(graphics, skin, x, y, size);
            }
         }
      }
   }

   private static class_2960 localTexture(String username) {
      String asset = assetName(username);
      if (!asset.isEmpty() && !MISSING.contains(asset)) {
         class_2960 id = (class_2960)TEXTURES.get(asset);
         if (id == null) {
            return null;
         } else {
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.method_1478() != null) {
               if (mc.method_1478().method_14489(id).isEmpty()) {
                  MISSING.add(asset);
                  return null;
               } else {
                  return id;
               }
            } else {
               return null;
            }
         }
      } else {
         return null;
      }
   }

   private static class_8685 resolveFromTab(String username) {
      class_310 mc = class_310.method_1551();
      if (mc != null && mc.method_1562() != null) {
         class_640 info = mc.method_1562().method_2874(username);
         if (info == null) {
            info = mc.method_1562().method_73471(username);
         }

         return info != null ? info.method_52810() : null;
      } else {
         return null;
      }
   }

   static {
      Map<String, String> files = new LinkedHashMap();
      files.put("archivestaticdebug", "archivestaticdebug");
      files.put("frwost", "frwost");
      files.put("fluffymaster07", "fluffymaster07");
      files.put("ogsummer", "0gsummer");
      files.put("w1zox_", "w1zox_");
      files.put("showered", "showered");
      files.put("itszdeath", "itszdeath");
      files.put("pastagamer", "pastagamer08");
      files.put("bautiegar", "bautiedgar");
      TEXTURE_FILES = Map.copyOf(files);
      Map<String, class_2960> textures = new LinkedHashMap();

      for(String file : TEXTURE_FILES.values()) {
         textures.put(file, class_2960.method_60655("staticdebug", "textures/admin/" + file + ".png"));
      }

      TEXTURES = Map.copyOf(textures);
   }
}
