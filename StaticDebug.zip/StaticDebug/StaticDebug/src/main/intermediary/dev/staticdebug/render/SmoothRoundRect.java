package dev.staticdebug.render;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_332;

public final class SmoothRoundRect {
   private static final float SAMPLE_SCALE = 1.35F;
   private static final int CACHE_LIMIT = 64;
   private static final Cache CACHE = new Cache(64, 0.75F, true);

   private SmoothRoundRect() {
   }

   public static void draw(class_332 ctx, int x, int y, int width, int height, int radius, int color) {
      if (ctx != null && width > 0 && height > 0 && color >>> 24 != 0) {
         draw(ctx, new Rect(x, y, width, height, radius), color);
      }
   }

   public static void roundRect(class_332 ctx, int x, int y, int width, int height, int radius, int color) {
      draw(ctx, x, y, width, height, radius, color);
   }

   public static void draw(class_332 ctx, Rect rect, int color) {
      if (ctx != null && rect != null && color >>> 24 != 0) {
         int x = rect.x();
         int y = rect.y();
         int width = rect.width();
         int height = rect.height();
         int r = rect.radius();
         if (r <= 0) {
            ctx.method_25294(x, y, x + width, y + height, color);
         } else {
            int right = x + width;
            int bottom = y + height;
            ctx.method_25294(x + r, y, right - r, bottom, color);
            ctx.method_25294(x, y + r, x + r, bottom - r, color);
            ctx.method_25294(right - r, y + r, right, bottom - r, color);
            float[] coverage = (float[])CACHE.computeIfAbsent(r, SmoothRoundRect::buildCornerCoverage);

            for(int py = 0; py < r; ++py) {
               int row = py * r;

               for(int px = 0; px < r; ++px) {
                  float cov = coverage[row + px];
                  if (!(cov <= 0.005F)) {
                     int cornerColor = withCoverage(color, cov);
                     ctx.method_25294(x + px, y + py, x + px + 1, y + py + 1, cornerColor);
                     ctx.method_25294(right - 1 - px, y + py, right - px, y + py + 1, cornerColor);
                     ctx.method_25294(x + px, bottom - 1 - py, x + px + 1, bottom - py, cornerColor);
                     ctx.method_25294(right - 1 - px, bottom - 1 - py, right - px, bottom - py, cornerColor);
                  }
               }
            }

         }
      }
   }

   private static float[] buildCornerCoverage(int radius) {
      float[] coverage = new float[radius * radius];
      double center = (double)radius - (double)0.5F;

      for(int py = 0; py < radius; ++py) {
         for(int px = 0; px < radius; ++px) {
            double dx = (double)px + (double)0.5F - center;
            double dy = (double)py + (double)0.5F - center;
            double dist = Math.sqrt(dx * dx + dy * dy);
            coverage[py * radius + px] = Math.max(0.0F, Math.min(1.0F, 0.5F + (float)((double)radius - dist) / 1.35F));
         }
      }

      return coverage;
   }

   private static int withCoverage(int argb, float coverage) {
      int alpha = Math.round((float)(argb >>> 24 & 255) * coverage);
      return alpha << 24 | argb & 16777215;
   }

   public static record Rect(int x, int y, int width, int height, int radius) {
      public Rect(int x, int y, int width, int height, int radius) {
         width = Math.max(0, width);
         height = Math.max(0, height);
         radius = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
         this.x = x;
         this.y = y;
         this.width = width;
         this.height = height;
         this.radius = radius;
      }
   }

   private static final class Cache extends LinkedHashMap<Integer, float[]> {
      private static final long serialVersionUID = 1L;
      private final int limit;

      private Cache(int limit, float loadFactor, boolean accessOrder) {
         super(Math.max(4, limit / 4), loadFactor, accessOrder);
         this.limit = Math.max(1, limit);
      }

      protected boolean removeEldestEntry(Map.Entry<Integer, float[]> eldest) {
         return this.size() > this.limit;
      }
   }
}
