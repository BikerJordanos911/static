#!/usr/bin/env sh
set -eu
gradle wrapper --gradle-version 8.14.3
