package dev.staticdebug.light;

import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.class_6606;

public final class PacketIntake {
   public static final ConcurrentLinkedQueue<PendingLight> QUEUE = new ConcurrentLinkedQueue();

   private PacketIntake() {
   }

   public static void offer(int chunkX, int chunkZ, class_6606 data) {
      if (data != null) {
         QUEUE.offer(new PendingLight(chunkX, chunkZ, data, System.nanoTime()));
      }

   }

   public static record PendingLight(int chunkX, int chunkZ, class_6606 data, long arrivalNanos) {
   }
}
