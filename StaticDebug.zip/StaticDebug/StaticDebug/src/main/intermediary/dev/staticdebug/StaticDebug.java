package dev.staticdebug;

import com.mojang.logging.LogUtils;
import dev.staticdebug.block.BlockCache;
import dev.staticdebug.light.LightCache;
import dev.staticdebug.modules.BaseCalc;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;

public class StaticDebug extends MeteorAddon {
   public static final Logger LOG = LogUtils.getLogger();
   public static final Category CATEGORY = new Category("StaticDebug");

   public void onInitialize() {
      LOG.info("[StaticDebug] Initializing (Java port)");
      Modules.get().add(new BaseCalc());
      LightCache.register();
      BlockCache.register();
   }

   public void onRegisterCategories() {
      Modules.registerCategory(CATEGORY);
   }

   public String getPackage() {
      return "dev.staticdebug";
   }
}
