package dev.staticdebug.light;

import dev.staticdebug.StaticDebug;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_310;
import net.minecraft.class_638;

public final class LightCache {
   public static final LightCache INSTANCE = new LightCache();
   public static final Long2ObjectOpenHashMap<ChunkLightSnapshot> SNAPSHOTS = new Long2ObjectOpenHashMap();
   private static final LongOpenHashSet ALERTED = new LongOpenHashSet();
   public static final int ALERT_MIN_Y = -64;
   public static final int ALERT_MAX_Y = 184;
   public static final int BASE_DETECT_CEILING_Y = 62;
   private static final int MAX_DRAIN_PER_TICK = 4096;
   private class_638 lastWorld = null;

   private LightCache() {
   }

   public static void register() {
      MeteorClient.EVENT_BUS.subscribe(INSTANCE);
   }

   public static boolean isChunkAlerted(long chunkKey) {
      return ALERTED.contains(chunkKey);
   }

   @EventHandler
   private void onTickPre(TickEvent.Pre event) {
      class_310 mc = class_310.method_1551();
      class_638 world = mc.field_1687;
      if (world != this.lastWorld) {
         if (!SNAPSHOTS.isEmpty()) {
            SNAPSHOTS.clear();
         }

         if (!ALERTED.isEmpty()) {
            ALERTED.clear();
         }

         PacketIntake.QUEUE.clear();
         this.lastWorld = world;
      }

      if (world != null) {
         if (mc.field_1724 != null && mc.field_1724.method_23318() < (double)0.0F) {
            PacketIntake.QUEUE.clear();
         } else {
            int sectionCount = world.method_32890();
            int bottomSectionY = world.method_32891();
            int drained = 0;

            PacketIntake.PendingLight pending;
            while((pending = (PacketIntake.PendingLight)PacketIntake.QUEUE.poll()) != null) {
               ingest(pending, sectionCount, bottomSectionY);
               ++drained;
               if (drained >= 4096) {
                  break;
               }
            }
         }
      }

   }

   private static void ingest(PacketIntake.PendingLight p, int sectionCount, int bottomSectionY) {
      long key = class_1923.method_8331(p.chunkX(), p.chunkZ());
      ChunkLightSnapshot snap = (ChunkLightSnapshot)SNAPSHOTS.get(key);
      if (snap == null || snap.sectionCount != sectionCount || snap.bottomSectionY != bottomSectionY) {
         snap = new ChunkLightSnapshot(p.chunkX(), p.chunkZ(), sectionCount, bottomSectionY);
         SNAPSHOTS.put(key, snap);
      }

      try {
         LightDataClassifier.apply(p.data(), snap, p.arrivalNanos());
      } catch (Throwable t) {
         StaticDebug.LOG.error("[Bypass] LightDataClassifier crashed on chunk " + p.chunkX() + "," + p.chunkZ(), t);
         return;
      }

      maybeAlert(p.chunkX(), p.chunkZ(), key, snap);
   }

}
