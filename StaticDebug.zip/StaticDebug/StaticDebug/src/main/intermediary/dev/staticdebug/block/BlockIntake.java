package dev.staticdebug.block;

import java.util.concurrent.ConcurrentLinkedQueue;

public final class BlockIntake {
   public static final ConcurrentLinkedQueue<PendingChunk> QUEUE = new ConcurrentLinkedQueue();

   private BlockIntake() {
   }

   public static void offer(int chunkX, int chunkZ) {
      QUEUE.offer(new PendingChunk(chunkX, chunkZ, System.nanoTime()));
   }

   public static record PendingChunk(int chunkX, int chunkZ, long arrivalNanos) {
   }
}
