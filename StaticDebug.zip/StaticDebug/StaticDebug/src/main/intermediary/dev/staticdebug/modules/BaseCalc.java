package dev.staticdebug.modules;

import dev.staticdebug.StaticDebug;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_638;

public class BaseCalc extends Module {
   private static final double SLAB_THICKNESS = 0.35;
   private static final int CHUNKS_PER_TICK = 8;
   private static final int RESCAN_INTERVAL = 200;
   private static final int CLUSTER_INTERVAL = 100;
   private static final int MIN_Y = -64;
   private static final int MAX_Y = 62;
   private static final int MIN_CLUSTER_SIZE = 2;
   private static final int RENDER_Y = 55;
   private static final String CHUNK_FOUND = "Chunk found at %d %d";
   private final SettingGroup sgGeneral;
   private final SettingGroup sgHoleFilter;
   private final SettingGroup sgChecks;
   private final SettingGroup sgAlerts;
   private final SettingGroup sgMemory;
   private final SettingGroup sgRender;
   private final Setting<Integer> simulationDistance;
   private final Setting<Integer> sensitivity;
   private final Setting<Boolean> preferLowHoles;
   private final Setting<Boolean> checkKelp;
   private final Setting<Boolean> checkCaveVine;
   private final Setting<Boolean> checkVines;
   private final Setting<Boolean> checkAmethyst;
   private final Setting<Boolean> checkBamboo;
   private final Setting<Boolean> checkCocoa;
   private final Setting<Boolean> checkBeeNest;
   private final Setting<Boolean> checkRotatedDeepslate;
   private final Setting<Boolean> checkWeirdSignals;
   private final Setting<Boolean> chatAlerts;
   private final Setting<Boolean> soundAlerts;
   private final Setting<Boolean> voiceSniff;
   private final Setting<Boolean> rememberPin;
   private final Setting<Boolean> clearRememberedPin;
   private final Setting<SettingColor> pillarColor;
   private final Setting<Integer> pillarOpacity;
   private static final List<class_2248> BASE_BLOCKS;
   private static final List<class_2248> ORE_BLOCKS;
   private final Long2ObjectOpenHashMap<ChunkEntry> chunks;
   private final LongOpenHashSet reportedChunks;
   private final ArrayDeque<Long> scanQueue;
   private final List<Candidate> candidates;
   private class_638 lastLevel;
   private class_1923 queueCenter;
   private int tickCounter;

   public BaseCalc() {
      super(StaticDebug.CATEGORY, "base-calculator", "Pins chunks with most base chance under or close to them");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgHoleFilter = this.settings.createGroup("Hole Filter");
      this.sgChecks = this.settings.createGroup("Checks");
      this.sgAlerts = this.settings.createGroup("Alerts");
      this.sgMemory = this.settings.createGroup("Memory");
      this.sgRender = this.settings.createGroup("Render");
      this.simulationDistance = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("simulation-distance")).description("Heat spread radius in chunks. Suggested for Donut bases: 3.")).defaultValue(3)).range(1, 20).sliderRange(1, 20).build());
      this.sensitivity = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("sensitivity")).description("Minimum growth heat before a chunk can be scored. Lower = flags more.")).defaultValue(1)).range(1, 16).sliderRange(1, 16).build());
      this.preferLowHoles = this.sgHoleFilter.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("prefer-low-holes")).description("Before pinning, scan an 8-chunk radius for digger holes. Under 3 holes = pin normally. 5+ holes = pin the chunk with the fewest holes instead.")).defaultValue(true)).build());
      this.checkKelp = this.sgChecks.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("kelp")).description("Count kelp growth signals.")).defaultValue(true)).build());
      this.checkCaveVine = this.sgChecks.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("cave-vine")).description("Count cave vine growth.")).defaultValue(true)).build());
      this.checkVines = this.sgChecks.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("vines")).description("Count vine growth.")).defaultValue(true)).build());
      this.checkAmethyst = this.sgChecks.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("amethyst")).description("Count amethyst clusters (smart section mode always on).")).defaultValue(true)).build());
      this.checkBamboo = this.sgChecks.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("bamboo")).description("Count bamboo growth.")).defaultValue(true)).build());
      this.checkCocoa = this.sgChecks.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("cocoa")).description("Count cocoa growth.")).defaultValue(true)).build());
      this.checkBeeNest = this.sgChecks.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("bee-nest")).description("Count bee nest honey.")).defaultValue(true)).build());
      this.checkRotatedDeepslate = this.sgChecks.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotated-deepslate")).description("Count enclosed rotated deepslate.")).defaultValue(true)).build());
      this.checkWeirdSignals = this.sgChecks.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("weird-signals")).description("Merge extra weird signals: powered repeaters, bees, cobbled deepslate, vine mass, seagrass.")).defaultValue(true)).build());
      this.chatAlerts = this.sgAlerts.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("chat-alerts")).description("Purple chat: Chunk found at X Z.")).defaultValue(true)).build());
      this.soundAlerts = this.sgAlerts.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("sound-alerts")).description("Play a soft chime when a base chunk pins.")).defaultValue(true)).build());
      this.voiceSniff = this.sgAlerts.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("voice-sniff")).description("Sniff Simple Voice Chat presence packets (does not move the base pin).")).defaultValue(true)).build());
      this.rememberPin = this.sgMemory.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("remember-pin")).description("Keep the pin across disconnect/reconnect while you're still near it. Leaves with you when you fly away.")).defaultValue(true)).build());
      this.clearRememberedPin = this.sgMemory.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("clear-remembered-pin")).description("Optional: force-forget now. Normally not needed — leaving the area auto-releases.")).defaultValue(false)).build());
      this.pillarColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("pillar-color")).description("4x4 pillar color (Y=-64 to 100).")).defaultValue(new SettingColor(160, 80, 255, 180)).build());
      this.pillarOpacity = this.sgRender.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("pillar-opacity")).description("Pillar fill opacity.")).defaultValue(180)).range(20, 255).sliderRange(40, 255).build());
      this.chunks = new Long2ObjectOpenHashMap();
      this.reportedChunks = new LongOpenHashSet();
      this.scanQueue = new ArrayDeque();
      this.candidates = new ArrayList();
   }

   public void onActivate() {
      this.clearState();
      this.lastLevel = this.mc.field_1687;
   }

   public void onDeactivate() {
      this.clearState();
      this.lastLevel = null;
   }

   public String getInfoString() {
      int var10000 = this.candidates.size();
      return var10000 + " candidates, " + this.chunks.size() + " suspicious chunks";
   }

   @EventHandler
   private void onChunkData(ChunkDataEvent event) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         class_1923 pos = event.chunk().method_12004();
         if (this.inRange(pos, this.playerChunk())) {
            long key = pos.method_8324();
            this.chunks.remove(key);
            if (!this.scanQueue.contains(key)) {
               this.scanQueue.addFirst(key);
            }

         }
      }
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      class_638 level = this.mc.field_1687;
      if (level != this.lastLevel) {
         this.clearState();
         this.lastLevel = level;
      }

      if (level != null && this.mc.field_1724 != null) {
         if ((Boolean)this.clearRememberedPin.get()) {
            this.reportedChunks.clear();
         }

         ++this.tickCounter;
         if (this.tickCounter % 200 == 0) {
            this.chunks.clear();
            this.queueCenter = null;
         }

         this.refillQueueIfNeeded();
         this.scanQueued();
         if (this.tickCounter % 100 == 0) {
            this.rebuildCandidates();
         }

      }
   }

   @EventHandler
   private void onRender3D(Render3DEvent event) {
      if (!this.candidates.isEmpty() && this.mc.field_1687 != null) {
         SettingColor color = (SettingColor)this.pillarColor.get();
         int alpha = (Integer)this.pillarOpacity.get();
         Color line = new Color(color.r, color.g, color.b, alpha);
         Color fill = new Color(color.r, color.g, color.b, Math.max(20, alpha / 3));
         double y = (double)55.0F;

         for(Candidate candidate : this.candidates) {
            double x1 = (double)(candidate.minCx() << 4);
            double z1 = (double)(candidate.minCz() << 4);
            double x2 = (double)(candidate.maxCx() + 1 << 4);
            double z2 = (double)(candidate.maxCz() + 1 << 4);
            event.renderer.box(new class_238(x1, y, z1, x2, y + 0.35, z2), fill, line, ShapeMode.Both, 0);
         }

      }
   }

   private void clearState() {
      this.chunks.clear();
      this.reportedChunks.clear();
      this.scanQueue.clear();
      this.candidates.clear();
      this.queueCenter = null;
      this.tickCounter = 0;
   }

   private class_1923 playerChunk() {
      int x = this.mc.field_1724.method_24515().method_10263() >> 4;
      int z = this.mc.field_1724.method_24515().method_10260() >> 4;
      return new class_1923(x, z);
   }

   private boolean inRange(class_1923 pos, class_1923 center) {
      int r = (Integer)this.simulationDistance.get();
      return Math.abs(pos.field_9181 - center.field_9181) <= r && Math.abs(pos.field_9180 - center.field_9180) <= r;
   }

   private void refillQueueIfNeeded() {
      class_1923 center = this.playerChunk();
      if (!center.equals(this.queueCenter) || this.scanQueue.isEmpty()) {
         this.queueCenter = center;
         int r = (Integer)this.simulationDistance.get();

         for(int dx = -r; dx <= r; ++dx) {
            for(int dz = -r; dz <= r; ++dz) {
               long key = class_1923.method_8331(center.field_9181 + dx, center.field_9180 + dz);
               if (!this.scanQueue.contains(key)) {
                  this.scanQueue.addLast(key);
               }
            }
         }

      }
   }

   private void scanQueued() {
      int budget = 8;

      for(int i = 0; i < budget && !this.scanQueue.isEmpty(); ++i) {
         long key = (Long)this.scanQueue.pollFirst();
         int cx = class_1923.method_8325(key);
         int cz = class_1923.method_8332(key);
         class_2818 chunk = this.mc.field_1687.method_2935().method_12126(cx, cz, false);
         if (chunk != null && !chunk.method_12223()) {
            this.scanChunk(chunk);
         }
      }

   }

   private void scanChunk(class_2818 chunk) {
      long key = chunk.method_12004().method_8324();
      class_2826[] sections = chunk.method_12006();
      int minSectionY = chunk.method_31607();
      int baseHits = 0;
      int oreHits = 0;

      for(int sectionIndex = 0; sectionIndex < sections.length; ++sectionIndex) {
         class_2826 section = sections[sectionIndex];
         if (section != null && !section.method_38292()) {
            int sectionBottomY = minSectionY + sectionIndex * 16;
            int lowY = Math.max(-64 - sectionBottomY, 0);
            int highY = Math.min(62 - sectionBottomY, 15);
            if (lowY <= highY) {
               for(int y = lowY; y <= highY; ++y) {
                  for(int z = 0; z < 16; ++z) {
                     for(int x = 0; x < 16; ++x) {
                        class_2680 state = section.method_12254(x, y, z);
                        if (!state.method_26215()) {
                           if (this.isBaseSignal(state)) {
                              ++baseHits;
                           } else if (ORE_BLOCKS.contains(state.method_26204())) {
                              ++oreHits;
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      if (baseHits + oreHits >= (Integer)this.sensitivity.get()) {
         this.chunks.put(key, new ChunkEntry(baseHits, oreHits));
      } else {
         this.chunks.remove(key);
      }

   }

   private boolean isBaseSignal(class_2680 state) {
      class_2248 block = state.method_26204();
      if (BASE_BLOCKS.contains(block)) {
         if (block != class_2246.field_20422 && block != class_2246.field_20421) {
            return block != class_2246.field_27159 && block != class_2246.field_27160 ? true : (Boolean)this.checkAmethyst.get();
         } else {
            return (Boolean)this.checkBeeNest.get();
         }
      } else if (!(Boolean)this.checkKelp.get() || block != class_2246.field_9993 && block != class_2246.field_10463) {
         if (!(Boolean)this.checkCaveVine.get() || block != class_2246.field_28675 && block != class_2246.field_28676) {
            if ((Boolean)this.checkVines.get() && block == class_2246.field_10597) {
               return true;
            } else if (!(Boolean)this.checkAmethyst.get() || block != class_2246.field_27161 && block != class_2246.field_27164 && block != class_2246.field_27163 && block != class_2246.field_27162) {
               if (!(Boolean)this.checkBamboo.get() || block != class_2246.field_10211 && block != class_2246.field_10108) {
                  if ((Boolean)this.checkCocoa.get() && block == class_2246.field_10302) {
                     return true;
                  } else if (!(Boolean)this.checkRotatedDeepslate.get() || block != class_2246.field_28888 && block != class_2246.field_29031) {
                     return (Boolean)this.checkWeirdSignals.get() && (block == class_2246.field_10450 || block == class_2246.field_10376 || block == class_2246.field_10238);
                  } else {
                     return true;
                  }
               } else {
                  return true;
               }
            } else {
               return true;
            }
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   private void rebuildCandidates() {
      this.prune();
      LongOpenHashSet visited = new LongOpenHashSet();
      List<Candidate> found = new ArrayList();
      LongIterator var3 = this.chunks.keySet().iterator();

      while(var3.hasNext()) {
         long seed = (Long)var3.next();
         if (visited.add(seed)) {
            ArrayDeque<Long> frontier = new ArrayDeque();
            frontier.add(seed);
            LongArrayList members = new LongArrayList();
            int score = 0;
            int sumX = 0;
            int sumZ = 0;
            int minCx = Integer.MAX_VALUE;
            int minCz = Integer.MAX_VALUE;
            int maxCx = Integer.MIN_VALUE;
            int maxCz = Integer.MIN_VALUE;

            while(!frontier.isEmpty()) {
               long key = (Long)frontier.pollFirst();
               ChunkEntry entry = (ChunkEntry)this.chunks.get(key);
               if (entry != null) {
                  int cx = class_1923.method_8325(key);
                  int cz = class_1923.method_8332(key);
                  members.add(key);
                  score += entry.totalHits();
                  sumX += cx;
                  sumZ += cz;
                  minCx = Math.min(minCx, cx);
                  minCz = Math.min(minCz, cz);
                  maxCx = Math.max(maxCx, cx);
                  maxCz = Math.max(maxCz, cz);

                  for(int dx = -1; dx <= 1; ++dx) {
                     for(int dz = -1; dz <= 1; ++dz) {
                        if (dx != 0 || dz != 0) {
                           long neighbour = class_1923.method_8331(cx + dx, cz + dz);
                           if (this.chunks.containsKey(neighbour) && visited.add(neighbour)) {
                              frontier.add(neighbour);
                           }
                        }
                     }
                  }
               }
            }

            if (members.size() >= 2) {
               int centroidCx = (int)Math.round((double)sumX / (double)members.size());
               int centroidCz = (int)Math.round((double)sumZ / (double)members.size());
               found.add(new Candidate(minCx, minCz, maxCx, maxCz, centroidCx, centroidCz, members.size(), score, members.toLongArray()));
            }
         }
      }

      found.sort(Comparator.comparingInt(Candidate::score).reversed());
      this.candidates.clear();
      this.candidates.addAll(found);

      for(Candidate candidate : found) {
         this.alert(candidate);
      }

   }

   private void alert(Candidate candidate) {
      boolean isNew = true;

      for(long key : candidate.members()) {
         if (this.reportedChunks.contains(key)) {
            isNew = false;
            break;
         }
      }

      if (isNew) {
         int worldX = (candidate.centroidCx() << 4) + 8;
         int worldZ = (candidate.centroidCz() << 4) + 8;
         Math.hypot((double)worldX - this.mc.field_1724.method_23317(), (double)worldZ - this.mc.field_1724.method_23321());

         for(long key : candidate.members()) {
            this.reportedChunks.add(key);
         }

         if ((Boolean)this.chatAlerts.get()) {
            ChatUtils.info(String.format("Chunk found at %d %d", worldX, worldZ), new Object[0]);
         }

         if ((Boolean)this.soundAlerts.get()) {
            this.mc.field_1724.method_5783((class_3414)class_3417.field_14622.value(), 0.6F, 1.4F);
         }

      }
   }

   private void prune() {
      class_1923 center = this.playerChunk();
      int r = (Integer)this.simulationDistance.get();
      LongArrayList stale = new LongArrayList();
      LongIterator var4 = this.chunks.keySet().iterator();

      while(var4.hasNext()) {
         long key = (Long)var4.next();
         int cx = class_1923.method_8325(key);
         int cz = class_1923.method_8332(key);
         if (Math.abs(cx - center.field_9181) <= r && Math.abs(cz - center.field_9180) <= r) {
            class_2818 chunk = this.mc.field_1687.method_2935().method_12126(cx, cz, false);
            if (chunk == null || chunk.method_12223()) {
               stale.add(key);
            }
         } else {
            stale.add(key);
         }
      }

      for(int i = 0; i < stale.size(); ++i) {
         this.chunks.remove(stale.getLong(i));
      }

      LongArrayList staleReported = new LongArrayList();
      LongIterator reportedIterator = this.reportedChunks.iterator();

      while(reportedIterator.hasNext()) {
         long key = (Long)reportedIterator.next();
         int cx = class_1923.method_8325(key);
         int cz = class_1923.method_8332(key);
         if (Math.abs(cx - center.field_9181) > r || Math.abs(cz - center.field_9180) > r) {
            staleReported.add(key);
         }
      }

      for(int i = 0; i < staleReported.size(); ++i) {
         this.reportedChunks.remove(staleReported.getLong(i));
      }

   }

   static {
      BASE_BLOCKS = List.of(class_2246.field_10034, class_2246.field_10380, class_2246.field_16328, class_2246.field_10443, class_2246.field_10260, class_2246.field_10603, class_2246.field_27159, class_2246.field_27160, class_2246.field_20422, class_2246.field_20421, class_2246.field_10485, class_2246.field_10535, class_2246.field_10327, class_2246.field_23152, class_2246.field_22423);
      ORE_BLOCKS = List.of(class_2246.field_22109, class_2246.field_10442, class_2246.field_29029, class_2246.field_10013, class_2246.field_29220, class_2246.field_10571, class_2246.field_29026);
   }

   private static record ChunkEntry(int baseHits, int oreHits) {
      int totalHits() {
         return this.baseHits + this.oreHits;
      }
   }

   private static record Candidate(int minCx, int minCz, int maxCx, int maxCz, int centroidCx, int centroidCz, int size, int score, long[] members) {
   }
}
