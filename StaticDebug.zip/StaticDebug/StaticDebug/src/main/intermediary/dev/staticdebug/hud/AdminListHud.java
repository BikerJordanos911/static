package dev.staticdebug.hud;

import dev.staticdebug.render.AdminHeadTextures;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import meteordevelopment.meteorclient.settings.Setting;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class AdminListHud {
   private static final int WIDTH = 188;
   private static final int HEADER_H = 24;
   private static final int ROW_H = 24;
   private static final int PAD = 8;
   private static final long ENTER_MS = 350L;
   private static final long EXIT_MS = 300L;
   private static final int TITLE = -1;
   private static final int NAME = -855304;
   private static final int ONLINE = -11147654;
   private static final int VANISH = -1664171;
   private static final int DIVIDER = -11838827;
   private static final int DOT = -7432520;
   private static final int SUBTLE = -7104331;
   private static final int PANEL = -1341124592;
   private final List<Row> rows = new ArrayList();
   private Setting<Integer> xSetting;
   private Setting<Integer> ySetting;
   private Setting<Integer> scaleSetting;

   public void run(Set<String> allKeys, Set<String> tabKeys, Set<String> serverKeys, boolean initialSeed) {
      long now = System.currentTimeMillis();
      if (initialSeed) {
         this.rows.clear();

         for(String key : allKeys) {
            if (serverKeys.contains(key)) {
               this.rows.add(new Row(key, tabKeys.contains(key), false));
            }
         }
      } else {
         for(String key : allKeys) {
            Row row = this.findRow(key);
            boolean online = tabKeys.contains(key);
            boolean server = serverKeys.contains(key);
            if (server) {
               if (row == null) {
                  this.rows.add(new Row(key, online, true));
               } else {
                  row.online = online;
                  row.entering = false;
                  row.leaving = false;
               }
            } else if (row != null) {
               row.leaving = true;
               row.entering = false;
               row.animStart = now;
            }
         }
      }

      this.rows.sort(Comparator.comparing((rowx) -> AdminHeadTextures.displayName(rowx.key).toLowerCase(Locale.ROOT)));
      this.pruneRows(now);
   }

   public void reset() {
      this.rows.clear();
   }

   public void configure(Setting<Integer> x, Setting<Integer> y, Setting<Integer> scale) {
      this.xSetting = x;
      this.ySetting = y;
      this.scaleSetting = scale;
   }

   public void render(class_332 graphics, Setting<Integer> x, Setting<Integer> y, Setting<Integer> scale) {
      this.configure(x, y, scale);
      if (graphics != null) {
         class_310 mc = class_310.method_1551();
         if (mc != null && mc.field_1772 != null) {
            long now = System.currentTimeMillis();
            this.pruneRows(now);
            float scaleFactor = this.settingFloat(scale, 100.0F) / 100.0F;
            if (scaleFactor <= 0.0F) {
               scaleFactor = 1.0F;
            }

            int posX = this.settingInt(x, 20);
            int posY = this.settingInt(y, 20);
            int panelHeight = this.panelHeight();
            graphics.method_51448().pushMatrix();
            graphics.method_51448().translate((float)posX, (float)posY);
            graphics.method_51448().scale(scaleFactor, scaleFactor);
            graphics.method_25294(0, 0, 188, panelHeight, -1341124592);
            graphics.method_25294(0, 0, 188, 1, withAlpha(-11838827, 255));
            drawText(graphics, "Admin Detect", 8, 7, -1, 1.0F);
            if (this.rows.isEmpty()) {
               drawText(graphics, "No admins tracked", 8, 32, withAlpha(-7104331, 200), 0.82F);
            } else {
               int rowY = 24;

               for(Row row : this.rows) {
                  if (this.shouldDrawRow(row, now)) {
                     float progress = this.rowProgress(row, now);
                     if (!(progress <= 0.01F) || !row.leaving) {
                        int alpha = clamp((int)(progress * 255.0F), 0, 255);
                        int slideX = row.leaving ? 0 : (int)((1.0F - easeOut(progress)) * 8.0F);
                        int slideY = row.leaving ? (int)((1.0F - progress) * -6.0F) : 0;
                        int rx = 8 + slideX;
                        int ry = rowY + slideY;
                        String name = AdminHeadTextures.displayName(row.key);
                        String status = row.online ? "Online" : "Vanish";
                        int statusColor = row.online ? -11147654 : -1664171;
                        AdminHeadTextures.drawHead(graphics, row.key, rx, ry + 4, 16);
                        drawText(graphics, name, rx + 20, ry + 3, withAlpha(-855304, alpha), 1.0F);
                        int nameWidth = mc.field_1772.method_1727(name);
                        int dotX = rx + 20 + nameWidth + 5;
                        drawText(graphics, "•", dotX, ry + 3, withAlpha(-7432520, alpha), 0.9F);
                        int statusX = dotX + mc.field_1772.method_1727("•") + 5;
                        drawText(graphics, status, statusX, ry + 4, withAlpha(statusColor, alpha), 0.82F);
                        drawText(graphics, row.online ? "Visible in tab" : "Currently in vanish", rx + 20, ry + 14, withAlpha(-7104331, alpha), 0.82F);
                        rowY += (int)(24.0F * progress);
                     }
                  }
               }
            }

            graphics.method_51448().popMatrix();
         }
      }
   }

   private int panelHeight() {
      int visibleRows = 0;
      long now = System.currentTimeMillis();

      for(Row row : this.rows) {
         if (this.shouldDrawRow(row, now)) {
            ++visibleRows;
         }
      }

      return visibleRows == 0 ? 50 : 24 + visibleRows * 24 + 8;
   }

   private Row findRow(String key) {
      for(Row row : this.rows) {
         if (row.key.equals(key)) {
            return row;
         }
      }

      return null;
   }

   private void pruneRows(long now) {
      Iterator<Row> iterator = this.rows.iterator();

      while(iterator.hasNext()) {
         Row row = (Row)iterator.next();
         if (row.leaving && this.rowProgress(row, now) <= 0.01F) {
            iterator.remove();
         }
      }

   }

   private boolean shouldDrawRow(Row row, long now) {
      return !row.leaving || this.rowProgress(row, now) > 0.01F;
   }

   private float rowProgress(Row row, long now) {
      long elapsed = now - row.animStart;
      if (row.leaving) {
         return 1.0F - easeOut(Math.min(1.0F, (float)elapsed / 300.0F));
      } else {
         return row.entering ? easeOut(Math.min(1.0F, (float)elapsed / 350.0F)) : 1.0F;
      }
   }

   private int settingInt(Setting<Integer> setting, int fallback) {
      if (setting == null) {
         return fallback;
      } else {
         Integer value = (Integer)setting.get();
         return value != null && value >= 0 ? value : fallback;
      }
   }

   private float settingFloat(Setting<Integer> setting, float fallback) {
      if (setting == null) {
         return fallback;
      } else {
         Integer value = (Integer)setting.get();
         return value == null ? fallback : value.floatValue();
      }
   }

   private static void drawText(class_332 graphics, String text, int x, int y, int color, float scale) {
      if (graphics != null && text != null && !text.isEmpty()) {
         class_310 mc = class_310.method_1551();
         if (mc != null && mc.field_1772 != null) {
            if (scale == 1.0F) {
               graphics.method_25303(mc.field_1772, text, x, y, color);
            } else {
               graphics.method_51448().pushMatrix();
               graphics.method_51448().translate((float)x, (float)y);
               graphics.method_51448().scale(scale, scale);
               graphics.method_25303(mc.field_1772, text, 0, 0, color);
               graphics.method_51448().popMatrix();
            }

         }
      }
   }

   private static float easeOut(float t) {
      float inverse = 1.0F - t;
      return 1.0F - inverse * inverse * inverse;
   }

   private static int withAlpha(int color, int alpha) {
      int sourceAlpha = color >>> 24 & 255;
      int a = sourceAlpha == 0 ? alpha : Math.min(alpha, sourceAlpha);
      return a << 24 | color & 16777215;
   }

   private static int clamp(int value, int min, int max) {
      return Math.max(min, Math.min(max, value));
   }

   private static final class Row {
      private final String key;
      private boolean online;
      private boolean entering;
      private boolean leaving;
      private long animStart;

      private Row(String key, boolean online, boolean animateEnter) {
         this.key = key;
         this.online = online;
         this.entering = animateEnter;
         this.leaving = !online && animateEnter;
         this.animStart = System.currentTimeMillis();
      }
   }
}
