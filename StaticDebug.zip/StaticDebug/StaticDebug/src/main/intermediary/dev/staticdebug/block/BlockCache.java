package dev.staticdebug.block;

import dev.staticdebug.StaticDebug;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_310;
import net.minecraft.class_638;

public final class BlockCache {
   public static final BlockCache INSTANCE = new BlockCache();
   public static final Long2ObjectOpenHashMap<BlockChunkSnapshot> SNAPSHOTS = new Long2ObjectOpenHashMap();
   private static final LongOpenHashSet ALERTED = new LongOpenHashSet();
   private static final int MAX_DRAIN_PER_TICK = 64;
   private class_638 lastWorld = null;

   private BlockCache() {
   }

   public static void register() {
      MeteorClient.EVENT_BUS.subscribe(INSTANCE);
   }

   public static boolean isChunkAlerted(long chunkKey) {
      return ALERTED.contains(chunkKey);
   }

   @EventHandler
   private void onTickPre(TickEvent.Pre event) {
      class_310 mc = class_310.method_1551();
      class_638 world = mc.field_1687;
      if (world != this.lastWorld) {
         if (!SNAPSHOTS.isEmpty()) {
            SNAPSHOTS.clear();
         }

         if (!ALERTED.isEmpty()) {
            ALERTED.clear();
         }

         BlockIntake.QUEUE.clear();
         this.lastWorld = world;
      }

      if (world != null) {
         if (mc.field_1724 != null && mc.field_1724.method_23318() < (double)0.0F) {
            BlockIntake.QUEUE.clear();
         } else {
            int sectionCount = world.method_32890();
            int bottomSectionY = world.method_32891();
            int drained = 0;

            BlockIntake.PendingChunk pending;
            while((pending = (BlockIntake.PendingChunk)BlockIntake.QUEUE.poll()) != null) {
               ingest(world, pending, sectionCount, bottomSectionY);
               ++drained;
               if (drained >= 64) {
                  break;
               }
            }
         }
      }

   }

   private static void ingest(class_638 world, BlockIntake.PendingChunk p, int sectionCount, int bottomSectionY) {
      long key = class_1923.method_8331(p.chunkX(), p.chunkZ());
      BlockChunkSnapshot snap = (BlockChunkSnapshot)SNAPSHOTS.get(key);
      if (snap == null || snap.sectionCount != sectionCount || snap.bottomSectionY != bottomSectionY) {
         snap = new BlockChunkSnapshot(p.chunkX(), p.chunkZ(), sectionCount, bottomSectionY);
         SNAPSHOTS.put(key, snap);
      }

      try {
         if (!BlockClassifier.apply(world, p.chunkX(), p.chunkZ(), snap, p.arrivalNanos())) {
            return;
         }
      } catch (Throwable t) {
         StaticDebug.LOG.error("[Bypass] BlockClassifier crashed on chunk " + p.chunkX() + "," + p.chunkZ(), t);
         return;
      }

      maybeAlert(p.chunkX(), p.chunkZ(), key, snap);
   }

}
