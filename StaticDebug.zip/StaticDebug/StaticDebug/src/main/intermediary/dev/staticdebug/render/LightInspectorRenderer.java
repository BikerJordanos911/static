package dev.staticdebug.render;

import dev.staticdebug.light.ChunkLightSnapshot;
import dev.staticdebug.light.LightCache;
import dev.staticdebug.light.SectionStatus;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_1923;
import net.minecraft.class_238;

public final class LightInspectorRenderer {
   private static final int MARKER_Y = 64;

   private LightInspectorRenderer() {
   }

   public static void draw(Render3DEvent event, Long2ObjectOpenHashMap<ChunkLightSnapshot> snapshots, int playerCx, int playerCz, int renderDistChunks, int opacity) {
      if (!snapshots.isEmpty()) {
         int alphaFilled = Math.max(8, Math.min(255, opacity / 3));
         int alphaLine = Math.max(20, Math.min(255, opacity));
         Color filled = new Color(SectionStatus.ZEROED_PRESENT.r(), SectionStatus.ZEROED_PRESENT.g(), SectionStatus.ZEROED_PRESENT.b(), alphaFilled);
         Color line = new Color(SectionStatus.ZEROED_PRESENT.r(), SectionStatus.ZEROED_PRESENT.g(), SectionStatus.ZEROED_PRESENT.b(), alphaLine);

         for(int cx = playerCx - renderDistChunks; cx <= playerCx + renderDistChunks; ++cx) {
            for(int cz = playerCz - renderDistChunks; cz <= playerCz + renderDistChunks; ++cz) {
               long key = class_1923.method_8331(cx, cz);
               ChunkLightSnapshot snap = (ChunkLightSnapshot)snapshots.get(key);
               if (snap != null) {
                  boolean shouldRender = LightCache.isChunkAlerted(key) || hasBaseSignal(snap);
                  if (shouldRender) {
                     int worldX = cx << 4;
                     int worldZ = cz << 4;
                     class_238 box = new class_238((double)worldX, (double)64.0F, (double)worldZ, (double)worldX + (double)16.0F, (double)65.0F, (double)worldZ + (double)16.0F);
                     event.renderer.box(box, filled, line, ShapeMode.Both, 0);
                  }
               }
            }
         }
      }

   }

   private static boolean hasBaseSignal(ChunkLightSnapshot snap) {
      int last = snap.sectionCount + 1;

      for(int i = 1; i < last; ++i) {
         int sectionTopY = (snap.bottomSectionY + (i - 1)) * 16 + 15;
         if (sectionTopY < 62 && snap.sky[i] == SectionStatus.ZEROED_PRESENT) {
            return true;
         }
      }

      return false;
   }
}
