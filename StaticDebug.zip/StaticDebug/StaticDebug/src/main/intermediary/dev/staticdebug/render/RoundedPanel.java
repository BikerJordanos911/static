package dev.staticdebug.render;

import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_332;

public final class RoundedPanel {
   private RoundedPanel() {
   }

   public static void fill(class_332 ctx, double x, double y, double width, double height, double radius, Color color) {
      fill(ctx, x, y, width, height, radius, color == null ? 0 : color.getPacked());
   }

   public static void fill(class_332 ctx, double x, double y, double width, double height, double radius, int argb) {
      rasterize(ctx, x, y, width, height, radius, argb, argb);
   }

   public static void fillGradient(class_332 ctx, double x, double y, double width, double height, double radius, Color top, Color bottom) {
      rasterize(ctx, x, y, width, height, radius, top == null ? 0 : top.getPacked(), bottom == null ? 0 : bottom.getPacked());
   }

   public static void fillGradient(class_332 ctx, double x, double y, double width, double height, double radius, int topArgb, int bottomArgb) {
      rasterize(ctx, x, y, width, height, radius, topArgb, bottomArgb);
   }

   public static void outline(class_332 ctx, double x, double y, double width, double height, double radius, double thickness, Color color) {
      outline(ctx, x, y, width, height, radius, thickness, color == null ? 0 : color.getPacked());
   }

   public static void outline(class_332 ctx, double x, double y, double width, double height, double radius, double thickness, int argb) {
      if (ctx != null && !(width <= (double)0.0F) && !(height <= (double)0.0F) && argb >>> 24 != 0) {
         int x0 = (int)Math.floor(x);
         int y0 = (int)Math.floor(y);
         int x1 = (int)Math.ceil(x + width);
         int y1 = (int)Math.ceil(y + height);
         int t = Math.max(1, (int)Math.round(thickness));
         t = Math.min(t, Math.min(x1 - x0, y1 - y0) / 2);
         if (t > 0) {
            double r = Math.max((double)0.0F, Math.min(radius, Math.min(width, height) / (double)2.0F));
            if (r < (double)1.0F) {
               ctx.method_25294(x0, y0, x1, y0 + t, argb);
               ctx.method_25294(x0, y1 - t, x1, y1, argb);
               ctx.method_25294(x0, y0 + t, x0 + t, y1 - t, argb);
               ctx.method_25294(x1 - t, y0 + t, x1, y1 - t, argb);
            } else {
               for(int py = y0; py < y1; ++py) {
                  double cy = (double)py + (double)0.5F;
                  double outerInset = cornerInset(cy, y, y + height, r);
                  double outerLeft = x + outerInset;
                  double outerRight = x + width - outerInset;
                  boolean insideTop = cy >= y + (double)t;
                  boolean insideBottom = cy <= y + height - (double)t;
                  if (insideTop && insideBottom) {
                     double innerInset = cornerInset(cy, y + (double)t, y + height - (double)t, Math.max((double)0.0F, r - (double)t));
                     double innerLeft = x + (double)t + innerInset;
                     double innerRight = x + width - (double)t - innerInset;
                     if (innerLeft > outerLeft) {
                        fillSpan(ctx, outerLeft, innerLeft, py, argb);
                     }

                     if (outerRight > innerRight) {
                        fillSpan(ctx, innerRight, outerRight, py, argb);
                     }
                  } else {
                     fillSpan(ctx, outerLeft, outerRight, py, argb);
                  }
               }

            }
         }
      }
   }

   private static void rasterize(class_332 ctx, double x, double y, double width, double height, double radius, int topArgb, int bottomArgb) {
      if (ctx != null && !(width <= (double)0.0F) && !(height <= (double)0.0F) && (topArgb | bottomArgb) >>> 24 != 0) {
         int y0 = (int)Math.floor(y);
         int y1 = (int)Math.ceil(y + height);
         double r = Math.max((double)0.0F, Math.min(radius, Math.min(width, height) / (double)2.0F));

         for(int py = y0; py < y1; ++py) {
            double cy = (double)py + (double)0.5F;
            double inset = cornerInset(cy, y, y + height, r);
            double leftExact = x + inset;
            double rightExact = x + width - inset;
            if (!(rightExact - leftExact < (double)0.5F)) {
               double t = Math.max((double)0.0F, Math.min((double)1.0F, (cy - y) / height));
               int argb = lerpArgb(topArgb, bottomArgb, t);
               int leftFull = (int)Math.ceil(leftExact);
               int rightFull = (int)Math.floor(rightExact);
               if (rightFull > leftFull) {
                  ctx.method_25294(leftFull, py, rightFull, py + 1, argb);
               }

               double leftFraction = (double)leftFull - leftExact;
               if (leftFraction > 0.01) {
                  ctx.method_25294(leftFull - 1, py, leftFull, py + 1, withAlphaFactor(argb, leftFraction));
               }

               double rightFraction = rightExact - (double)rightFull;
               if (rightFraction > 0.01) {
                  ctx.method_25294(rightFull, py, rightFull + 1, py + 1, withAlphaFactor(argb, rightFraction));
               }
            }
         }

      }
   }

   private static void fillSpan(class_332 ctx, double leftExact, double rightExact, int py, int argb) {
      if (!(rightExact - leftExact < (double)0.5F)) {
         int leftFull = (int)Math.ceil(leftExact);
         int rightFull = (int)Math.floor(rightExact);
         if (rightFull > leftFull) {
            ctx.method_25294(leftFull, py, rightFull, py + 1, argb);
         }

      }
   }

   private static double cornerInset(double scanline, double top, double bottom, double radius) {
      if (radius <= (double)0.5F) {
         return (double)0.0F;
      } else {
         double dy;
         if (scanline < top + radius) {
            dy = top + radius - scanline;
         } else {
            if (!(scanline > bottom - radius)) {
               return (double)0.0F;
            }

            dy = scanline - (bottom - radius);
         }

         return dy >= radius ? radius : radius - Math.sqrt(radius * radius - dy * dy);
      }
   }

   private static int lerpArgb(int from, int to, double t) {
      int fromA = from >>> 24 & 255;
      int fromR = from >>> 16 & 255;
      int fromG = from >>> 8 & 255;
      int fromB = from & 255;
      int toA = to >>> 24 & 255;
      int toR = to >>> 16 & 255;
      int toG = to >>> 8 & 255;
      int toB = to & 255;
      int a = (int)Math.round((double)fromA + (double)(toA - fromA) * t);
      int r = (int)Math.round((double)fromR + (double)(toR - fromR) * t);
      int g = (int)Math.round((double)fromG + (double)(toG - fromG) * t);
      int b = (int)Math.round((double)fromB + (double)(toB - fromB) * t);
      return a << 24 | r << 16 | g << 8 | b;
   }

   private static int withAlphaFactor(int argb, double factor) {
      int alpha = (int)Math.round((double)(argb >>> 24 & 255) * Math.max((double)0.0F, Math.min((double)1.0F, factor)));
      return alpha << 24 | argb & 16777215;
   }
}
